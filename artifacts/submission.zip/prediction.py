"""Training and inference share exactly the same booking transformations."""
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

NUMERIC = [
    'days_ahead', 'weekend_nights', 'weekday_nights', 'adults', 'children',
    'babies', 'returning_guest', 'past_cancellations', 'past_stays',
    'amendments', 'waitlist_days', 'nightly_rate', 'special_requests', 'nights',
    'arrival_month_number', 'arrival_weekday', 'arrival_day', 'arrival_week',
    'booking_month', 'booking_weekday',
]
CATEGORICAL = [
    'hotel', 'meal', 'country', 'sales_segment', 'sales_channel', 'room_type',
    'deposit', 'agent', 'company', 'guest_type',
]


def features(bookings):
    frame = pd.DataFrame([bookings]) if isinstance(bookings, dict) else bookings.copy()
    arrival = pd.to_datetime(frame['arrival_date'])
    booked = pd.to_datetime(frame['booking_date'])
    frame['arrival_month_number'] = arrival.dt.month
    frame['arrival_weekday'] = arrival.dt.day_of_week
    frame['arrival_day'] = arrival.dt.day
    frame['arrival_week'] = arrival.dt.isocalendar().week.astype(float)
    frame['booking_month'] = booked.dt.month
    frame['booking_weekday'] = booked.dt.day_of_week
    for name in NUMERIC:
        frame[name] = pd.to_numeric(frame[name], errors='coerce') if name in frame else np.nan
    for name in CATEGORICAL:
        values = frame[name] if name in frame else pd.Series(np.nan, index=frame.index)
        if name in ('agent', 'company'):
            # CSV IDs such as 304.0 and inference IDs such as 304 are identical.
            values = pd.to_numeric(values, errors='coerce').map(
                lambda v: str(float(v)) if pd.notna(v) else np.nan
            )
        frame[name] = values.map(lambda v: str(v) if pd.notna(v) and str(v) else 'Unknown')
    return frame[NUMERIC + CATEGORICAL]


def make_model(kind='logistic'):
    if kind != 'logistic':
        raise ValueError('Only logistic regression is supported')
    numeric = Pipeline([('fill', SimpleImputer(strategy='median', keep_empty_features=True)),
                        ('scale', StandardScaler())])
    transform = ColumnTransformer([
        ('numeric', numeric, NUMERIC),
        ('categorical', OneHotEncoder(handle_unknown='ignore'), CATEGORICAL),
    ])
    classifier = LogisticRegression(max_iter=1500, random_state=42)
    return Pipeline([('features', transform), ('classifier', classifier)])


class CancellationModel:
    def __init__(self, pipeline):
        self.pipeline = pipeline

    def predict_batch(self, bookings):
        if len(bookings) == 0:
            return np.array([], dtype=float)
        classes = list(self.pipeline.classes_)
        if 1 not in classes:
            return np.zeros(len(bookings))
        probability = self.pipeline.predict_proba(features(bookings))[:, classes.index(1)]
        return probability

    def predict_cancellation(self, booking):
        return float(self.predict_batch(pd.DataFrame([booking]))[0])

    def save(self, path):
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        joblib.dump({'pipeline': self.pipeline}, path)

    @classmethod
    def load(cls, path):
        saved = joblib.load(path)
        if isinstance(saved, dict) and saved.get('calibrator') is not None:
            raise ValueError('Calibrated models are retired; retrain logistic regression')
        return cls(saved['pipeline'] if isinstance(saved, dict) else saved)


def read_bookings(path='train.csv'):
    data = pd.read_csv(path, parse_dates=['arrival_date', 'booking_date'])
    data['checkout'] = data['arrival_date'] + pd.to_timedelta(data['nights'], unit='D')
    return data
